class SongCart < ApplicationRecord
 belongs_to :cart
 belongs_to :song
end
