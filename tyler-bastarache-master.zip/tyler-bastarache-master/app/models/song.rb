class Song < ApplicationRecord
  has_many :user_songs
  has_many :users, through: :user_songs
  has_many :song_carts

  has_one_attached :background_image
  has_one_attached :audio_file


  def background_image_url
    Rails.application.routes.url_helpers.url_for(self.background_image) if self.background_image.attachment
  end

  def audio_file_url
    Rails.application.routes.url_helpers.url_for(self.audio_file) if self.audio_file.attachment
  end
end
