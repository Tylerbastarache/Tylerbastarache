class Cart < ApplicationRecord
  has_many :song_carts
  has_many :songs, through: :song_carts
  belongs_to :user
end
