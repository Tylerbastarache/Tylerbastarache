# class ApplicationController < ActionController::Base
#   protect_from_forgery with: :null_session
# end

# frozen_string_literal: true

class ApplicationController < ActionController::Base
  protect_from_forgery with: :null_session

  before_action :get_current_user
  # add_flash_types :success, :warning, :danger, :info

  # include Pundit

  helper_method :current_user

  # protect_from_forgery with: :exception
  # rescue_from ActionController::InvalidAuthenticityToken do
  #   flash[:alert] = I18n.t('app.authenticity_token_expired')
  #   redirect_back fallback_location: root_path, allow_other_host: false
  # end

  # rescue_from Pundit::NotAuthorizedError do |_exception|
  #   head :forbidden
  # end

  def current_institution
    @current_institution ||= Institution.find_by_id(session[:current_institution_id])
    @current_institution ||= Institution.find(current_user&.last_logged_in_institution) if current_user&.last_logged_in_institution&.present?
    @current_institution ||= current_user&.institutions&.first
  end

  # def pundit_user
  #   # UserConstext.new(current_user, current_institution, '172.89.16.11')
  #   UserContext.new(current_user, current_institution, request.remote_ip)
  # end

  private

  def get_current_user
    return if current_user
    user = app_user
    if user
      sign_in(:user, user)
    end
  end

  def app_user
    user_token  = request.headers['user-token']
    return unless  user_token

    crypt = ActiveSupport::MessageEncryptor.new(ENV['MOBILE_SECRET_KEY'].byteslice(0..31))
    token = crypt.decrypt_and_verify user_token
    user_id = token.gsub('user-id:', '').to_i
    User.find user_id
  rescue ActiveSupport::MessageVerifier::InvalidSignature, ActiveSupport::MessageEncryptor::InvalidMessage
    nil
  end
  # A shorthand for passing locals to views, avoiding implicitly passed instance
  # variables.
  #
  # The following calls are equivalent to each other:
  #   render action: :new, locals: { the_anser: 42 }
  #   expose :new, the_answer: 42
  #
  #   render locals: { the_anser: 42 }
  #   expose the_anser: 42
  #
  # @param action [Symbol] action to render, only necessary if not default
  # @param locals [Hash<Symbol, Object>] locals to be passed to the view
  # @return [void]
  def expose(action = nil, **locals)
    render action: action, locals: locals
  end

  def after_sign_out_path_for(resource_or_scope)
    users_login_path
  end

end
