class HomeController < ApplicationController

  def index
  end
  
  def execute
    # Get payment ID from query string following redirect
    payment = Payment.find(params[:paymentId])
    # Execute payment with the payer ID from query string following redirect
    if payment.execute(payer_id: params[:PayerID] )  #return true or false
      user = User.find(params[:user_id])
      user.song_ids |= user.cart.song_ids
      user.cart.destroy
      logger.info "Payment[#{payment.id}] executed successfully"
      redirect_to music_path
    else
      logger.error payment.error.inspect
    end
  end

  def error
  end
end
