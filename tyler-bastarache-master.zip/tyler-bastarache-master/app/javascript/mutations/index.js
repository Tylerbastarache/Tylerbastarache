import { gql } from "@apollo/client";

const USER_SIGN_UP = gql`
  mutation(
    $email: String!
    $password: String!
    $passwordConfirmation: String!
  ) {
    signUpUser(
      email: $email
      password: $password
      passwordConfirmation: $passwordConfirmation
    ) {
      email
      id
    }
  }
`;

const USER_SIGN_IN = gql`
  mutation($credentials: AuthProviderCredentialsInput!) {
    signInUser(credentials: $credentials) {
      error
      token
      user {
        id
        name
      }
    }
  }
`;

const CHECKOUT = gql`
  mutation($songIds: [Int!]!) {
    checkout(songIds: $songIds) {
      error
      url
    }
  }
`;

const ADD_NEW_MUSIC = gql`
  mutation(
    $title: String!
    $audioFile: File!
    $price: String!
    $description: String!
    $backgroundImage: Upload!
  ) {
    createSong(
      title: $title
      audioFile: $audioFile
      price: $price
      description: $description
      backgroundImage: $backgroundImage
    ) {
      audioFileUrl
      backgroundImageUrl
      description
      id
      title
      price
    }
  }
`;

const ADD_TO_CART = gql`
  mutation($songId: Int!) {
    addToCart(songId: $songId) {
      id
    }
  }
`;

export { USER_SIGN_UP, USER_SIGN_IN, ADD_NEW_MUSIC, ADD_TO_CART, CHECKOUT };
