import {
  ApolloClient,
  ApolloLink,
  HttpLink,
  InMemoryCache,
} from "@apollo/client";
import { setContext } from "@apollo/link-context";
import { createUploadLink } from "apollo-upload-client";
// import localForage from "localforage";
// import { BASE_URL } from "./config";
// const BASE_URL = "http://81603c195dbb.ngrok.io";
// const BASE_URL = "https://tyler-music.herokuapp.com";
const BASE_URL = window.location.origin;

const GRAPHQL_API_URL = `${BASE_URL}/graphql`;

const getToken = async () => {
  try {
    return localStorage.getItem("user-token");
  } catch (e) {
    console.log("localstorage error");
  }
};

const asyncAuthLink = setContext(async () => {
  console.log("getToken()", getToken());
  const TOKEN = await getToken();
  // const TOKEN =
  //   "CoGM+QGsCRiGkV1u1THsnkoiBQ==--bR+ewh3O1l8/12gV--KrXOLfuscTY9duOL2ppVvg==";
  return {
    headers: {
      "user-token": TOKEN,
    },
  };
});

const httpLink = new HttpLink({
  uri: GRAPHQL_API_URL,
  credentials: "omit",
});

const cache = new InMemoryCache({});

const apolloLink = ApolloLink.split(
  (operation) => operation.getContext().hasUpload,
  createUploadLink({ uri: GRAPHQL_API_URL }),
  httpLink
);

export const apolloClient = new ApolloClient({
  cache: cache,
  link: asyncAuthLink.concat(apolloLink),
});
