import React from 'react'
import Footer from '../../components/Footer'
import TylerHeader from '../../components/TylerHeader'
import { Grid } from '@material-ui/core'

const TylerLayout = (props) => {

  const { component: Component, showAdmin, noFooterSpacing } = props


  return (
    <>
      <TylerHeader showAdmin={showAdmin} />
      <Grid style={{
        minHeight: noFooterSpacing ? 'calc(100vh - 105px)' : 'calc(100vh - 154px)',
        marginTop: '55px'
      }}>
        <Component />
      </Grid>
      <Footer noFooterSpacing={noFooterSpacing}/>
    </>
  )
}

export default TylerLayout
