import React from 'react'
import { Grid } from '@material-ui/core'
import LoginHeader from '../../components/LoginHeader'

const LoginLayout = (props) => {

  const { component: Component} = props
  return (
    <>
      <LoginHeader/>
      <Component />
    </>
  )
}

export default LoginLayout
