import { gql } from "@apollo/client";

const CURRENT_USER = gql`
  query {
    getCurrentUser {
      id
      name
      email
    }
  }
`;
const MUSICS = gql`
  query {
    songs {
      songs {
        audioFileUrl
        backgroundImageUrl
        description
        id
        price
        title
      }
      mySongs {
        audioFileUrl
        backgroundImageUrl
        description
        id
        price
        title
      }
    }
  }
`;

const CART = gql`
  query {
    cart {
      id
      songs {
        audioFileUrl
        backgroundImageUrl
        description
        id
        price
        title
      }
    }
  }
`;
export { CURRENT_USER, MUSICS, CART };
