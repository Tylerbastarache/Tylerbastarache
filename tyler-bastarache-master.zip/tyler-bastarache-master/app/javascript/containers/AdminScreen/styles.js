const styles = theme => ({


  addNewButton: {
    backgroundColor: '#1f1f1f',
    color: '#fff',
    padding: '1px 40px',
    borderRadius: '7px',
    fontSize: '23px',
    textDecoration: 'none',
    textTransform: 'lowercase',
    "&:hover": {
      backgroundColor: '#1f1f1f',
    }
  }

})

export default styles
