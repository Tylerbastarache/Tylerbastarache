import React from 'react'
import { Button } from '@material-ui/core'
import { Link } from 'react-router-dom'
import withStyles from '@material-ui/core/styles/withStyles'
import styles from './styles'

const AdminScreen = ({ classes }) => {
  return (
    <div>
      <Link to="/add-new-music" style={{ textDecoration: 'none' }}>
        <Button className={classes.addNewButton}>
          Add a New Music
        </Button>
      </Link>
    </div>
  )
}

export default withStyles(styles)(AdminScreen)
