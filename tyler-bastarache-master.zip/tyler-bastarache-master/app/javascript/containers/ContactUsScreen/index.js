import React from 'react'
import styles from './styles'
import withStyles from "@material-ui/core/styles/withStyles"
import { Box, Checkbox, FormControlLabel, Grid, Typography, Button, Divider, Container } from '@material-ui/core'

const ContactUsScreen = ({ classes }) => {
  return (
    <Container>
      <Box py={4} style={{ paddingTop: '30px'}}>
        <Grid item xs={12}>
          <Typography variant='h2' className={classes.contactUsTitle}>
            contact
          </Typography>
          <Typography className={classes.contactUsDesc}>
            if you have any questions related to design or music,
          </Typography>
          <Typography className={classes.contactUsDesc}>
            fill up the boxes below and i will try to awnser as soon
          </Typography>
          <Typography className={classes.contactUsDesc}>
            as possible.
          </Typography>
        </Grid>
      </Box>
      <Grid container item sm={12} md={8}>
        {/* <Grid style={{flex: '0.7'}}> */}
          <Grid container style={{ maxWidth:'250px'}}>
          <input placeholder="name" type="type" className={classes.emailField} />
        </Grid>
        <Grid container>
          <input placeholder="email" type="email" className={classes.emailField} />
        </Grid>
        <Grid container style={{ maxWidth: '250px' }}>
          <input placeholder="subject" type="text" className={classes.emailField} />
        </Grid>
        <Grid container>
          <textarea placeholder="message" type="text" className={classes.messageField} />
        </Grid>
        <Grid container justify='flex-end'>
          <Button className={classes.sendButton}>
            send
          </Button>
          </Grid>
          </Grid>
      {/* </Grid> */}
    </Container>
  )
}

export default withStyles(styles)(ContactUsScreen)
