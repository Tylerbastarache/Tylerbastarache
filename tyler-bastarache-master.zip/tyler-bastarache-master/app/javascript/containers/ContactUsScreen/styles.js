const styles = theme => ({

  loginHeaderContainer: {
    borderBottom: '1px solid #000',
    padding: '15px 0'
  },

  contactUsTitle: {
    fontSize: "24pt",
    marginBottom: '24.5px',
    lineHeight: '0.8',
    fontFamily: '"Playfair Display", serif'
  },

  contactUsDesc: {
    lineHeight: '1.2',
    fontFamily: '"Inter", sans-serif',
    fontSize: '16pt'
  },

  emailField: {
    borderRadius: '6px',
    border: '1px solid #000',
    padding: '10px 15px',
    width: '100%',
    marginBottom: '1.5rem'
  },

  messageField: {
    borderRadius: '6px',
    border: '1px solid #000',
    padding: '10px 15px',
    width: '100%',
    height: '300px',
    marginBottom: '1.5rem'
  },

  sendButton: {
    backgroundColor: '#1f1f1f',
    color: '#fff',
    padding: '0px 40px',
    borderRadius: '7px',
    fontSize: '17px',
    width: '100%',
    maxWidth: '120px',
    textTransform: 'lowercase',
    border: '1px solid black',
    '&:hover': {
      backgroundColor: '#fff',
      color: '#000',
    },
  }

})

export default styles
