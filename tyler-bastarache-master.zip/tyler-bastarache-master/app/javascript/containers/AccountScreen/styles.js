const styles = theme => ({

  input:focus => ({
    border: "none"
  }),

  header: {
    fontWeight: "bold",
    paddingBottom: "55px",
    fontFamily: '"Playfair Display", serif !important',
    fontSize: "27px"
  },

  formContainer: {
    padding: "45px 0 0 0"
  },

  inputContainer: {
    borderBottom: "1px solid black",
    paddingBottom: "10px"
  },

  inputLabel: {
    // paddingRight: "180px",
    display: "inline-block",
    width: "300px",
    fontSize: "17px",
    fontWeight: "400"
  },

  inputFeield: {
    border: "none",
    width: "390px",
    fontSize: "17px",
    fontWeight: "400",
    '&:focus-visible': {
      outline: 'none'
    }
  },

  inputBlock: {
    padding: "10px 0"
  },

  profileButton: {
    marginTop: "50px",
    background: "black",
    color: "white",
    textTransform: "capitalize",
    borderRadius: "8px",
    fontWeight: "400",
    fontSize: "18px",
    padding: "9px 34px",
    fontFamily: '"Inter", sans-serif',
  }

})

export default styles
