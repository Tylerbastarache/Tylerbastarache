import React, {useState} from 'react'
import { Typography, withStyles, Grid, Button, Container } from '@material-ui/core';
import styles from './styles'
import PurachaseHistory from '../../components/PurchaseHistory'

const AccountScreen = (props) => {

  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [country, setCountry] = useState("")
  const [dateOfBirth, setDateOfBirth] = useState("")

  const { classes } = props
  return (
    <Container>
      <Grid className={ classes.formContainer}>
        <Grid className={ classes.header}>
          account overview
        </Grid>
        <Grid className={classes.inputBlock}>
          <label className={ classes.inputContainer}>
            <span className={ classes.inputLabel}>email</span>
            <input type="email" name="name" value={email} onChange={(e) => { setEmail(e.target.value)}} className={ classes.inputFeield}/>
          </label>
        </Grid>
        <br />

        <Grid className={classes.inputBlock}>
          <label className={ classes.inputContainer}>
            <span className={ classes.inputLabel}>password</span>
            <input type="password" name="name" value={password} onChange={(e) => { setPassword(e.target.value)}} className={ classes.inputFeield}/>
          </label>
        </Grid>
        <br/>

        <Grid className={classes.inputBlock}>
          <label className={ classes.inputContainer}>
            <span className={ classes.inputLabel}>country</span>
            <input type="text" name="name" value={country} onChange={(e) => { setCountry(e.target.value)}} className={ classes.inputFeield}/>
          </label>
        </Grid>
        <br/>

        <Grid className={classes.inputBlock}>
          <label className={ classes.inputContainer}>
            <span className={ classes.inputLabel}>date of birth</span>
            <input type="text" name="name" value={dateOfBirth} onChange={(e) => { setDateOfBirth(e.target.value)}} className={ classes.inputFeield}/>
          </label>
        </Grid>

        <Button variant="contained" className={classes.profileButton }>
          <Grid style={{fontWeight: "400"}}>Edit Profile</Grid>
        </Button>
        <PurachaseHistory/>
      </Grid>
    </Container>
      )
}

export default  withStyles(styles)(AccountScreen)
