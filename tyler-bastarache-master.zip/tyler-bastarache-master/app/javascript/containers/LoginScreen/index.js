import React, { useState, useContext } from "react";
import styles from "./styles";
import withStyles from "@material-ui/core/styles/withStyles";
import {
  Box,
  Checkbox,
  FormControlLabel,
  Grid,
  Typography,
  Button,
  Divider,
  Snackbar,
} from "@material-ui/core";
import { Link, useHistory } from "react-router-dom";
import { CheckBox, CheckBoxOutlineBlank } from "@material-ui/icons";
import { withApollo } from "@apollo/client/react/hoc";
import { USER_SIGN_IN } from "mutations";
import UserContext from '../App/UserContext'

const LoginScreen = ({ classes, client }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [snackBar, setSnackBar] = useState(false)
  const { setCurrentUser } = useContext(UserContext)
  let history = useHistory();

  const submitForm = () => {
    console.log("email", email, "password", password);
    client
      .mutate({
        mutation: USER_SIGN_IN,
        variables: {
          credentials: {
            email: email,
            password: password,
          },
        },
      })
      .then((res) => {
        if (res.data.signInUser.token) {
          localStorage.setItem("user-token", res.data.signInUser.token);
          setCurrentUser(res.data.signInUser.user)
          history.push("/music");
        } else {
          setSnackBar(true)
        }
      })
      .catch((err) => {
        console.log("err", err);
        setSnackBar(true)
      });
  };

  return (
    <Grid container justify="center" className={classes.loginScreenContainer}>
      <Grid className={classes.fieldsContainer}>
        <Box mb={5}>
          <Typography align="center" style={{ fontSize: '16pt' }}>
            to continue, log in to tyler bastarache
          </Typography>
        </Box>
        <Box mb={3}>
          <Box mb={1}>
            <Typography variant='h4' style={{ fontSize: '16pt' }}>email address</Typography>
          </Box>
          <input
            placeholder="email"
            type="email"
            onChange={(e) => setEmail(e.target.value)}
            className={classes.emailField}
          />
        </Box>
        <Box mb={3}>
          <Box mb={1}>
            <Typography variant='h4' style={{ fontSize: '16pt' }}>password</Typography>
          </Box>
          <input
            placeholder="password"
            type="password"
            onChange={(e) => setPassword(e.target.value)}
            className={classes.emailField}
          />
        </Box>
        <Box mb={3}>
          <a href="https://www.google.com" className={classes.forgotPassword}>
            forgot your password?
          </a>
        </Box>
        <Grid container justify="space-between">
          <FormControlLabel
            control={
              <Checkbox
                icon={<CheckBoxOutlineBlank fontSize="meduim" />}
                checkedIcon={<CheckBox fontSize="meduim" />}
                name="checkedI"
              />
            }
            label={<Typography style={{fontSize: '16pt'}}>remember me</Typography>}
          />
          <Button onClick={submitForm} className={classes.loginButton}>
            log in
          </Button>
        </Grid>
        <Box mt={3}>
          <Divider className={classes.dividerLine} />
        </Box>
        <Box my={3}>
          <Typography variant='h5' align="center" style={{ fontSize: "16pt" }}>
            don't have an account?
          </Typography>
        </Box>
        <Grid container>
          <Link to="/sign-up" className={classes.signUpLink}>
            <Button className={classes.signUpButton}>sign up</Button>
          </Link>
        </Grid>
      </Grid>
      <Snackbar
        open={snackBar}
        onClose={() => setSnackBar(false)}
        autoHideDuration={5000}
        message="Something went wrong"
      />
    </Grid>
  );
};

export default withStyles(styles)(withApollo(LoginScreen));
