const styles = theme => ({

  loginScreenContainer: {
    height: 'calc(100vh - 85px)'
  },

  emailField: {
    borderRadius: '6px',
    border: '1px solid #000',
    padding: '10px 8px',
    width: '100%',
    fontSize: '16pt',
    maxWidth: '450px'
  },

  fieldsContainer: {
    maxWidth: '470px',
    width: '100%',
    padding: '5rem 2rem'
  },

  forgotPassword: {
    textDecoration: 'underline',
    fontSize: '16pt',
    color: 'gray'
  },

  loginButton: {
    backgroundColor: '#1f1f1f',
    color: '#fff',
    padding: '1px 40px',
    borderRadius: '7px',
    fontSize: '23px',
    textTransform: 'lowercase',
    border: '1px solid black',
    '&:hover': {
      backgroundColor: '#fff',
      color: '#000',
    },
  },

  dividerLine: {
    background: 'black',
    height: '2px'
  },

  signUpButton: {
    backgroundColor: '#1f1f1f',
    color: '#fff',
    padding: '0px 40px',
    borderRadius: '7px',
    fontSize: '23px',
    width: '100%',
    textTransform: 'lowercase',
    border: '1px solid black',
    '&:hover': {
      backgroundColor: '#fff',
      color: '#000',
    },
  },

  signUpLink: {
    width: '100%',
    textDecoration: 'none'
  }

})

export default styles
