import React, { useState, useRef, useEffect } from "react";
import styles from "./styles";
import {
  Box,
  CircularProgress,
  Container,
  Grid,
  Typography,
} from "@material-ui/core";
import { withApollo } from "@apollo/client/react/hoc";

import withStyles from "@material-ui/core/styles/withStyles";
import CheckoutList from "../../components/CheckoutList";
import CheckoutOptions from "../../components/CheckoutOptions";
import OrderConfimationModal from "../../components/OrderConfimationModal";
import { useQuery } from "@apollo/client";
import { CART } from "../../queries";
import { CHECKOUT } from "../../mutations";

import { sum } from "lodash";

const CheckoutScreen = ({ classes, client }) => {
  const [openCheckoutModal, setOpenCheckoutModal] = useState(false);

  const paymentCheckout = () => {
    console.log(
      "hhhhhh",
      client,
      data.cart?.songs?.map((song) => parseInt(song.id))
    );
    client
      .mutate({
        mutation: CHECKOUT,
        variables: {
          songIds: data.cart?.songs?.map((song) => parseInt(song.id)),
        },
      })
      .then((res) => {
        setOpenCheckoutModal(false);
        console.log("res is: ", res);
        window.open(res.data.checkout.url);
      })
      .catch((res) => {
        console.log("error:", res.message);
        setOpenCheckoutModal(false);
        setError(res.message);
      });
  };

  const { data, loading, error } = useQuery(CART);

  const getPrice = () =>
    sum(data.cart?.songs?.map((song) => parseInt(song.price || 0)));

  if (loading) return <CircularProgress />;

  if (error) return `Error! ${error}`;

  if (data)
    return (
      <Container maxWidth="lg">
        {/* <ImageGalleryDescription /> */}
        <Box pt={4} mb={3} style={{ paddingTop: '30px'}}>
          <Typography variant="h2" className={classes.loginTitle}>
            Bag
          </Typography>
        </Box>
        <Grid container item xs={12}>
          <Grid item lg={9} sm={8}>
            <CheckoutList cartData={data.cart} />
          </Grid>
          <Grid item lg={3} sm={4}>
            <CheckoutOptions
              setOpenCheckoutModal={setOpenCheckoutModal}
              price={getPrice()}
            />
          </Grid>
        </Grid>
        <OrderConfimationModal
          openCheckoutModal={openCheckoutModal}
          setOpenCheckoutModal={setOpenCheckoutModal}
          paymentCheckout={paymentCheckout}
        />
      </Container>
    );
};

export default withStyles(styles)(withApollo(CheckoutScreen));
