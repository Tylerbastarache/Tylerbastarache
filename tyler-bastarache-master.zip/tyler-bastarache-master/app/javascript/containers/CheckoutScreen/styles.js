const styles = theme => ({

  loginTitle: {
    fontSize: "24pt",
    fontFamily: '"Playfair Display", serif'
  }

})

export default styles
