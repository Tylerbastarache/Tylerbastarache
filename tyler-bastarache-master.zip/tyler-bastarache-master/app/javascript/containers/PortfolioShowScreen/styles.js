const styles = theme => ({

  loginHeaderContainer: {
    borderBottom: '1px solid #000',
    padding: '15px 0'
  },

  portfolioTitle: {
    fontSize: "24pt",
    marginBottom: '24px'
  },

  portfolioDesc: {
    lineHeight: '1.2',
    fontSize: '16pt'
  },

  portfolioThumb: {
    // width: '90%',
    height: 'calc(100vh - 136px)',
    padding: '1rem',
    position: 'relative',
    backgroundColor: 'lavender',
    width: '60vw',
    [theme.breakpoints.down('1440')]: {
      marginLeft: 'calc(20vw - 35%)'
    },
    [theme.breakpoints.up('1440')]: {
      marginLeft: 'calc(-50vw)',
      left: '66.5%'
    },
    [theme.breakpoints.down('sm')]: {
      width: '100%',
      marginBottom: '1rem',
      height: '300px',
      marginLeft: '0',
      left: 'unset'
    }
  },


})

export default styles
