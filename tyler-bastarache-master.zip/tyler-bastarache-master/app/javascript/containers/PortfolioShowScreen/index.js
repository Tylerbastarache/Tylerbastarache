import React from 'react'
import styles from './styles'
import withStyles from "@material-ui/core/styles/withStyles"
import ReadMoreReact from 'read-more-react';
import { Box, Checkbox, FormControlLabel, Grid, Typography, Button, Divider, Container } from '@material-ui/core'

const PortfolioShowScreen = ({ classes }) => {
  return (
    <Container>
      <Box>
        <Grid container>
          <Grid container item lg={9} md={8} xs={12} >
            <Grid className={classes.portfolioThumb}></Grid>
          </Grid>
          <Grid container alignItems='flex-end' item lg={3} md={4} xs={12} style={{ paddingTop: '40px'}}>
            <Grid>
              <Typography variant='h2' className={classes.portfolioTitle}>
                tesla annual report
              </Typography>
              <Typography className={classes.portfolioDesc}>
                lorem ipsum dolor sit amet,
                consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et
                dolore magna aliqua.

              </Typography>
              <Typography className={classes.portfolioDesc} style={{ marginBottom: '1rem'}}>
                ut enim ad minim veniam, quis nostrud
                exercitation ullamco laboris nisi ut
                aliquip ex ea commodo consequat.
                duis aute irure dolor in reprehenderit in
                voluptate. dolor sit amet, consectetur
                adipiscing elit, sed do eiusmod tempor
                incididunt ut
              </Typography>
              <Typography className={classes.portfolioDesc}>
                <ReadMoreReact
                  text="lorem ipsum dolor sit amet,
                  consectetur adipiscing elit, sed do
                  eiusmod tempor incididunt ut labore.
                  aliquip ex ea commodo consequat.
                  duis aute irure dolor in reprehenderit in
                  voluptate. dolor sit amet, consectetur
                  adipiscing elit, sed"
                  readMoreText={<div style={{ marginTop: '2rem'}}>more info</div>}
                />

              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </Box>
    </Container>
  )
}

export default withStyles(styles)(PortfolioShowScreen)
