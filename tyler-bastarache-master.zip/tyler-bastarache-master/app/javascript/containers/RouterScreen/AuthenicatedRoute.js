import React, { useContext } from 'react'
import { Redirect } from 'react-router-dom'
import UserContext from "../App/UserContext"
import { Route } from "react-router-dom";

const AuthenicatedRoute = (props) => {

  const { currentUser } = useContext(UserContext)

  const { children, ...other } = props

  if (!currentUser)
    return (
      <Redirect to="/login" />
    )

  return (
    <>
      <Route {...other}>
        {children}
      </Route>
    </>
  )

}

export default AuthenicatedRoute
