import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import TylerLayout from "../../layouts/TylerLayout";
import LoginLayout from "../../layouts/LoginLayout";
import CheckoutScreen from "../CheckoutScreen";
import ContactUsScreen from "../ContactUsScreen";
import LoginScreen from "../LoginScreen";
import MusicGalleryScreen from "../MusicGalleryScreen";
import SignUpScreen from "../SignUpScreen";
import PortfolioScreen from "../PortfolioScreen";
import AboutScreen from "../AboutScreen";
import AuthenicatedRoute from "./AuthenicatedRoute";
import AdminScreen from "../AdminScreen";
import AddMusicScreen from "../AddMusicScreen";
import PortfolioShowScreen from "../PortfolioShowScreen";
import AccountScreen from '../AccountScreen'

const RouterScreen = () => {
  return (
    <Router>
      <Switch>
        <Route exact path="/">
          <TylerLayout component={PortfolioScreen} />
        </Route>

        <Route exact path="/portfolio/:id">
          <TylerLayout component={PortfolioShowScreen} noFooterSpacing={true} />
        </Route>

        <Route exact path="/music">
          <TylerLayout component={MusicGalleryScreen} showAdmin={true} />
        </Route>

        <AuthenicatedRoute exact path="/admin">
          <TylerLayout component={AdminScreen} />
        </AuthenicatedRoute>


        <AuthenicatedRoute exact path="/account">
          <TylerLayout component={AccountScreen} />
        </AuthenicatedRoute>


        <AuthenicatedRoute exact path="/add-new-music">
          <TylerLayout component={AddMusicScreen} />
        </AuthenicatedRoute>

        <Route exact path="/contact-us">
          <TylerLayout component={ContactUsScreen} />
        </Route>

        <Route exact path="/about">
        <TylerLayout component={AboutScreen} noFooterSpacing={true} />
        </Route>

        <Route exact path="/execute">
          <TylerLayout component={AboutScreen} />
        </Route>

        <Route exact path="/login">
          <LoginLayout component={LoginScreen} />
        </Route>
        <Route exact path="/sign-up">
          <LoginLayout component={SignUpScreen} />
        </Route>
        <AuthenicatedRoute exact path="/checkout">
          <TylerLayout component={CheckoutScreen} />
        </AuthenicatedRoute>
      </Switch>
    </Router>
  );
};
export default RouterScreen;
