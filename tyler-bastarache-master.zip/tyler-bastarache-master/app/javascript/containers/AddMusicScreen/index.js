import React, { useState } from 'react'
import styles from './styles'
import { withApollo } from '@apollo/client/react/hoc'
import withStyles from "@material-ui/core/styles/withStyles"
import { Box, Checkbox, FormControlLabel, Grid, Typography, Button, Divider, Snackbar } from '@material-ui/core'
import { CheckBox, CheckBoxOutlineBlank } from '@material-ui/icons'
import { ADD_NEW_MUSIC } from '../../mutations'
import { useHistory } from 'react-router-dom'
// import Dropzone from 'react-dropzone'
import Dropzone from '../../components/DropZone'

const AddMusicScreen = ({ classes, client }) => {

  const [title, setTitle] = useState("")
  const [price, setPrice] = useState("")
  const [desc, setDesc] = useState("")
  const [audio, setAudio] = useState(null)
  const [thumb, setThumb] = useState(null)
  const [error, setError] = useState(null)

  let history = useHistory()

  const addNewMusicHandle = () => {
    console.log("audio", audio, "thumb", thumb)
    client.mutate({
      mutation: ADD_NEW_MUSIC,
      context: { hasUpload: true },
      variables: {
        title: title,
        price: price,
        description: desc,
        audioFile: audio,
        backgroundImage: thumb
      }
    }).then((res) => {
      history.push('/admin')
    }).catch((res) => {
      setError(res.message)
    })
  }

  const handleFile = (file) => {
    setAudio(file)
  }


  return (
    <Grid container justify='center' className={classes.musicScreenContainer}>
      <Grid className={classes.fieldsContainer}>
        <Box mb={5}>
          <Typography align='center' >
            Add a new Music
          </Typography>
        </Box>
        <Box mb={2}>
          <Box mb={1}>
            <Typography style={{ fontWeight: '700' }}>
              Title
            </Typography>
          </Box>
          <input placeholder="title" type="text" onChange={(e) => setTitle(e.target.value)} className={classes.emailField} />
        </Box>
        <Box mb={2}>
          <Box mb={1}>
            <Typography style={{ fontWeight: '700' }}>
              Description
            </Typography>
          </Box>
          <input placeholder="description" type="text" onChange={(e) => setDesc(e.target.value)} className={classes.emailField} />
        </Box>
        <Box mb={3}>
          <Box mb={1}>
            <Typography style={{ fontWeight: '700' }}>
              Price
            </Typography>
          </Box>
          <input placeholder="price" type="text" onChange={(e) => setPrice(e.target.value)} className={classes.emailField} />
        </Box>
        <Box mb={2}>
          <Box mb={1}>
            <Typography style={{ fontWeight: '700' }}>
              Audio
            </Typography>
          </Box>
          {/* <Dropzone handleFile={(file) => setAudio(file) }/> */}
          <input
            placeholder="confirm password"
            type="file"
            onChange={(e) => {
              setAudio(e.target.files[0])
              }}
            className={classes.emailField}
          />
          {/* <Dropzone
            // accept="image/*"
            multiple={false} // Only upload 1 file
            onDrop={files => {
              console.log("file", files)
              setAudio(files[0])
              // updateUser({
              //   variables: {
              //     image: files[0]
              //   }
              // });
            }}
          >
          {({getRootProps, getInputProps}) => (
    <section>
      <div {...getRootProps()}>
        <input {...getInputProps()} />
        <p>Drag 'n' drop some files here, or click to select files</p>
      </div>
    </section>
  )}

          </Dropzone> */}
        </Box>
        <Box mb={2}>
          <Box mb={1}>
            <Typography style={{ fontWeight: '700' }}>
              Thumbnail
            </Typography>
          </Box>
          <input placeholder="confirm file" type="file" onChange={(e) => setThumb(e.target.files[0])} className={classes.emailField} />
          {/* <Dropzone handleFile={(file) => setThumb(file) }/> */}
        </Box>
        <Grid container>
          <Button onClick={addNewMusicHandle} className={classes.signUpButton}>
              Add Music
          </Button>
        </Grid>
      </Grid>
      <Snackbar
        open={error}
        onClose={() => setError(null)}
        autoHideDuration={5000}
        message={error}
      />
    </Grid>
  )
}

export default withStyles(styles)(withApollo(AddMusicScreen))
