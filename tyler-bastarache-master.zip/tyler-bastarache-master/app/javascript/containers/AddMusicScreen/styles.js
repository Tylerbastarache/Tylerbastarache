const styles = theme => ({

  musicScreenContainer: {
    // height: 'calc(100vh - 110px)'
  },

  emailField: {
    borderRadius: '6px',
    border: '1px solid #000',
    padding: '10px 8px',
    width: '100%',
    maxWidth: '450px'
  },

  fieldsContainer: {
    maxWidth: '470px',
    width: '100%',
    padding: '5rem 2rem'
  },

  signUpButton: {
    backgroundColor: '#1f1f1f',
    color: '#fff',
    padding: '0px 40px',
    borderRadius: '7px',
    fontSize: '23px',
    width: '100%',
    textTransform: 'lowercase',
    "&:hover": {
      backgroundColor: '#1f1f1f',
    }
  }

})

export default styles
