import React, { useState } from 'react'
import styles from './styles'
import withStyles from "@material-ui/core/styles/withStyles"
import { Box, Checkbox, FormControlLabel, Grid, Typography, Button, Divider, Snackbar } from '@material-ui/core'
import { CheckBox, CheckBoxOutlineBlank } from '@material-ui/icons'
import { Link, useHistory } from 'react-router-dom'
import { withApollo } from '@apollo/client/react/hoc'
import { USER_SIGN_UP } from 'mutations'

const SignUpScreen = ({ classes, client }) => {

  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [snackBar, setSnackBar] = useState(false)
  let history = useHistory();

  const submitForm = () => {
    client.mutate({
      mutation: USER_SIGN_UP,
      variables: {
        email: email,
        password: password,
        passwordConfirmation: password
      }
    }).then((res) => {
      console.log("res", res)
      history.push("/login");
    }).catch((err) => {
      console.log("err", err)
      setSnackBar(true)
    })
  }

  return (
    <Grid container justify='center' className={classes.signUpScreenContainer}>
      <Grid className={classes.fieldsContainer}>
        <Box mb={5}>
          <Typography align='center' style={{ fontSize: '16pt' }} >
            sign up with your email address
          </Typography>
        </Box>
        <Box mb={3}>
          <Box mb={1}>
            <Typography variant='h4' style={{ fontSize: '16pt' }}>
              what’s your email
            </Typography>
          </Box>
          <input placeholder="email" type="email" onChange={(e) => setEmail(e.target.value)} className={classes.emailField} />
        </Box>
        <Box mb={3}>
          <Box mb={1}>
            <Typography variant='h4' style={{ fontSize: '16pt' }}>
              create a password
            </Typography>
          </Box>
          <input placeholder="password" type="password" onChange={(e) => setPassword(e.target.value)} className={classes.emailField} />
        </Box>
        <Box mb={3}>
          <Box mb={1}>
            <Typography variant='h4' style={{ fontSize: '16pt' }}>
              confirm password
            </Typography>
          </Box>
          <input placeholder="confirm password" type="password" onChange={(e) => setPassword(e.target.value)} className={classes.emailField} />
        </Box>
        <Box mb={3}>
          <FormControlLabel
            control={
              <Checkbox
                icon={<CheckBoxOutlineBlank fontSize="medium" />}
                checkedIcon={<CheckBox fontSize="medium" />}
                name="checkedI"
              />
            }
            label={<Typography style={{fontSize: '16pt'}}>keep me updated</Typography>}
          />
        </Box>
        <Grid container>
          <Button onClick={submitForm} className={classes.signUpButton}>
              sign up
          </Button>
        </Grid>
        <Box mt={3}>
          <Typography variant='h5' align='center' style={{ fontSize: "16pt" }}>
            have an account? <Link to="/login" style={{  color: 'gray' }}>log in</Link>
          </Typography>
        </Box>
      </Grid>
      <Snackbar
        open={snackBar}
        onClose={() => setSnackBar(false)}
        autoHideDuration={5000}
        message="Something went wrong"
      />
    </Grid>
  )
}

export default withStyles(styles)(withApollo(SignUpScreen))
