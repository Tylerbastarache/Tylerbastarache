import React, { useState, useRef, useEffect } from 'react'
import ImageGalleryDescription from '../../components/ImageGalleryDescription';
import { Container } from '@material-ui/core';
import ImageGalleryMedia from '../../components/ImageGalleryMedia';

const MusicGalleryScreen = ({ classes }) => {


  return (
    <Container maxWidth='lg'>
      <ImageGalleryDescription />
      <ImageGalleryMedia />
    </Container>
  )

}

export default MusicGalleryScreen
