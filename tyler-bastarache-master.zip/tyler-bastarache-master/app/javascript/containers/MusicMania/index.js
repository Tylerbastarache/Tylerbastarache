import React, { useContext } from 'react'
import { Query } from "@apollo/client/react/components"
import { CURRENT_USER } from '../../queries'
import UserContext from '../App/UserContext'
import { CircularProgress, Grid, Typography } from '@material-ui/core'
import RouterScreen from '../RouterScreen'


const MusicMania = () => {

  const { setCurrentUser, currentUser } = useContext(UserContext)

  const initialUser = (data) => {
    if (data.getCurrentUser)
      setCurrentUser(data.getCurrentUser)
    else
      setCurrentUser(null)
  }

  return (
    <Query query={CURRENT_USER} onCompleted={initialUser}>
      {({ loading, error }) => {
        if (error)
          return <Typography>Error: {error}</Typography>

        if (loading || currentUser === false)
          return <CircularProgress />

        return <RouterScreen />
      }}
    </Query>
  )
}

export default MusicMania
