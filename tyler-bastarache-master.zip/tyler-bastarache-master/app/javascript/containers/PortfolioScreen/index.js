import React from "react";
import styles from "./styles";
import withStyles from "@material-ui/core/styles/withStyles";
import {
  Box,
  Checkbox,
  FormControlLabel,
  Grid,
  Typography,
  Button,
  Divider,
  Container,
} from "@material-ui/core";
import { Link } from "react-router-dom";
// import { Link }

const data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

const PortfolioScreen = ({ classes }) => {
  return (
    <Container style={{ paddingTop: "14px", paddingLeft: '7px', paddingRight: '7px' }}>
      <Grid container justify="flex-start" className={classes.portfolioContainer}>
        {data.map((value) => (
          <Box my={2} mx={2}>
            <Link to='portfolio/1'>
              <Grid
                container
                justify="flex-end"
                alignItems="flex-end"
                className={classes.portThumb}
              />
            </Link>
          </Box>
        ))}
      </Grid>
    </Container>
  );
};

export default withStyles(styles)(PortfolioScreen);
