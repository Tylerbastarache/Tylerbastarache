const styles = theme => ({

  portThumb: {
    width: '441px',
    height: '270px',
    padding: '1rem',
    position: 'relative',
    backgroundColor: 'lavender',
    [theme.breakpoints.down('sm')]: {
      width: '320px',
    }
  },

  portfolioContainer: {
    [theme.breakpoints.down('sm')]: {
      justifyContent: 'center'
    }
  }

})

export default styles
