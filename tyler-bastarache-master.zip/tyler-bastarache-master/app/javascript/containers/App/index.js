import React, { useEffect, useState } from 'react'
import { ApolloProvider } from '@apollo/client';
import { UserProvider } from "./UserContext"
import { apolloClient } from '../../apollo/index'
import MusicMania from '../MusicMania';

const App = () => {

  const [currentUser, setCurrentUser] = useState(false)

  return (
    <UserProvider value={{ currentUser, setCurrentUser }}>
      <ApolloProvider client={apolloClient}>
        <MusicMania />
      </ApolloProvider>
    </UserProvider>
  )
}

export default App
