const styles = theme => ({

  loginHeaderContainer: {
    borderBottom: '1px solid #000',
    padding: '15px 0'
  },

  aboutTitle: {
    fontSize: "24pt",
    marginBottom: '28px',
    lineHeight: '0.7'
  },

  aboutDesc: {
    lineHeight: '1.2',
    fontSize: '16pt'
  },

  aboutThumb: {
    // width: '85%',
    padding: '1rem',
    position: 'relative',
    minHeight: 'calc(100vh - 136px)',
    backgroundColor: 'lavender',
    width: '60vw',
    [theme.breakpoints.down('1440')]: {
      marginLeft: 'calc(20vw - 35%)'
    },
    [theme.breakpoints.up('1440')]: {
      marginLeft: 'calc(-50vw)',
      left: '66.5%'
    },
    [theme.breakpoints.down('sm')]: {
      width: '100%',
      marginBottom: '1rem',
      height: '300px',
      minHeight: '300px',
      marginLeft: '0'
    }
  },


})

export default styles
