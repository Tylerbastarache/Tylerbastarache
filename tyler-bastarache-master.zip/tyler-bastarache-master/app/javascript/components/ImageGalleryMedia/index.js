import React, { useState, useContext, useEffect } from "react";
import styles from "./styles";
import withStyles from "@material-ui/core/styles/withStyles";
import AudioCard from "../AudioCard";

import {
  Grid,
  Typography,
  Box,
  CircularProgress,
  Snackbar,
} from "@material-ui/core";
import { useQuery } from "@apollo/client";
import { MUSICS, CURRENT_USER } from "../../queries";
import { withApollo } from "@apollo/client/react/hoc";
import UserContext from "../../containers/App/UserContext";
import { ADD_TO_CART } from "../../mutations";
import { Link, useHistory } from 'react-router-dom'


const ImageGalleryMedia = (props) => {
  const { classes, client } = props;

  const [progress, setProgress] = useState(0);
  const [currentPlayer, setCurrentPlayer] = useState(null);
  const [showSnackBar, setShowSnackbar] = useState(false);
  const { currentUser } = useContext(UserContext)
  let history = useHistory()


  const resetAllPlayers = () => {
    currentPlayer && currentPlayer.element.pause();
    setCurrentPlayer(null);
    setProgress(0);
  };

  const playAudio = (id) => {
    resetAllPlayers();
    let audioElement = document.getElementById(`audio_player_${id}`);
    setCurrentPlayer({ id: id, element: audioElement });
    audioElement.play();
  };

  const stopAudio = (id) => {
    let audioElement = document.getElementById(`audio_player_${id}`);
    setCurrentPlayer(null);
    audioElement.pause();
    setProgress(0);
  };

  const addToCart = (songId) => {
    console.log("songId", songId);
    if (!currentUser) {
      history.push('/login')
      return
    }
    client
      .mutate({
        mutation: ADD_TO_CART,
        variables: {
          songId: parseInt(songId),
        },
      })
      .then((res) => {
        setShowSnackbar(true);
      })
      .catch((err) => {
        console.log("err", err);
      });
  };

  const { data, loading, error } = useQuery(MUSICS);

  useEffect(() => {
    console.log("data: ", data);
  }, [data]);

  if (loading) return <CircularProgress />;

  if (error) return `Error! ${error}`;
  if (data) console.log("data: ", data);
  const musicCard = (audio, chip) => {
    return (
      <AudioCard
        progress={progress}
        duration={currentPlayer && currentPlayer.element.duration}
        isActive={currentPlayer && currentPlayer.id === audio.id}
        audioId={audio.id}
        title={audio.title}
        price={audio.price}
        thumb={audio.backgroundImageUrl}
        src={audio.audioFileUrl}
        addToCart={addToCart}
        setProgress={setProgress}
        playAudio={playAudio}
        stopAudio={stopAudio}
        showChip={chip}
        purchased={!chip}
      />
    );
  };

  if (data)
    return (
      <Box>
        <Grid
          container
          justify="space-between"
          className={classes.musicContainer}
        >
          {data.songs.mySongs.map((audio) => musicCard(audio, false))}
          <br />
          {data.songs.songs.map((audio) => musicCard(audio, true))}
        </Grid>
        {
          <Snackbar
            open={showSnackBar}
            onClose={() => setShowSnackbar(false)}
            autoHideDuration={5000}
            message="Added to Cart"
          />
        }
      </Box>
    );
};

export default withStyles(styles)(withApollo(ImageGalleryMedia));
