const styles = theme => ({

  loginHeaderContainer: {
    borderBottom: '1px solid #000',
    padding: '15px 0'
  },

  loginTitle: {
    fontSize: "26px"
  },

  musicContainer: {
    [theme.breakpoints.down('xs')]: {
      justifyContent: 'center'
    }
  }

})

export default styles
