import React from 'react'
import styles from './styles'
import withStyles from "@material-ui/core/styles/withStyles"
import { Grid, Typography, Box } from '@material-ui/core'
const ImageGalleryDescription = ({ classes }) => {
  return (
    <Box style={{ padding: '30px 0 52px 0'}}>
      <Grid item xs={12} lg={7} >
        <Typography variant='h2' className={classes.loginTitle}>
          exclusive beats
        </Typography>
        <Typography style={{ fontSize: '16pt', lineHeight: '1.2'}}>
          all instrumentals are exclusive with no producer tag, this includes the full rights and comes with the option to change/edit the beat’s composition and layout. for more information contact me at <strong>tyler.bastarache@hotmail.com</strong>
        </Typography>
      </Grid>
    </Box>
  )
}

export default withStyles(styles)(ImageGalleryDescription)
