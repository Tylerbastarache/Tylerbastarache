const styles = theme => ({

  loginHeaderContainer: {
    borderBottom: '1px solid #000',
    padding: '15px 0'
  },

  loginTitle: {
    fontSize: "24pt",
    lineHeight: '0.7',
    marginBottom: '24.5px'
  }

})

export default styles
