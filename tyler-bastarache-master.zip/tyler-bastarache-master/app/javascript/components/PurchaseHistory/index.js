import React from 'react'
import { withStyles, Grid } from '@material-ui/core';
import styles from './styles'
const PurachaseHistory = (props) => {

  const { classes } = props
  const numbers = [1, 2, 3, 4, 5, 6];
  return (
    <div>
      <Grid className={ classes.header}>
        purchase history
      </Grid>
      <Grid container direction="row" justify="space-between">
          {
            numbers.map((number) => {
              return (
                <>
                  <Grid>
                    <Grid className={classes.boxes}></Grid>
                    <Grid className={classes.boxText}>Cravate</Grid>
                  </Grid>
                </>
              )

            })
          }
        </Grid>
    </div>
  )
}

export default withStyles(styles)(PurachaseHistory)
