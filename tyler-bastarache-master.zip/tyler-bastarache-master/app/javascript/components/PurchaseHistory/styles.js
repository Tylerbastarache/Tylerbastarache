const styles = theme => ({

  input:focus => ({
    border: "none"
  }),

  header: {
    fontWeight: "bold",
    padding: "55px 0 35px 0",
    fontFamily: '"Playfair Display", serif !important',
    fontSize: "27px"
  },

  boxes: {
    background: "black",
    width: "185px",
    height: "190px",
    marginBottom: "1rem"
  },

  boxText: {
    fontFamily: '"Inter", sans-serif',
    fontWeight: "400",
    fontSize: "18px",
    textTransform: "lowercase"
  }

})

export default styles
