import React, { useState } from "react";
import styles from "./styles";
import withStyles from "@material-ui/core/styles/withStyles";
import { Grid, Typography, Box, Button } from "@material-ui/core";

const CheckoutOptions = (props) => {
  const { classes, price, setOpenCheckoutModal } = props;

  return (
    <Grid>
      <Typography align="center" className={classes.checkoutTitle}>
        your bag total is ${price}
      </Typography>
      <Button
        onClick={() => setOpenCheckoutModal(true)}
        className={classes.checkoutButton}
      >
        checkout
      </Button>
    </Grid>
  );
};

export default withStyles(styles)(CheckoutOptions);
