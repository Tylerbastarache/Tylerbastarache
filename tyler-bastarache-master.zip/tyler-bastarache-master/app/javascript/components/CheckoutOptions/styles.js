const styles = theme => ({

  loginHeaderContainer: {
    borderBottom: '1px solid #000',
    padding: '15px 0'
  },

  checkoutTitle: {
    fontSize: "24pt",
    marginBottom: '2.5rem',
    lineHeight: '1'
  },

  checkoutButton: {
    backgroundColor: '#1f1f1f',
    color: '#fff',
    padding: '0px 40px',
    borderRadius: '7px',
    fontSize: '24pt',
    width: '100%',
    textTransform: 'lowercase',
    "&:hover": {
      backgroundColor: '#1f1f1f',
    }
  }

})

export default styles
