import React from 'react'
import styles from './styles'
import withStyles from '@material-ui/core/styles/withStyles'
import { Typography, Grid, Container } from '@material-ui/core';
import { Link, useHistory } from 'react-router-dom'
import MenuIcon from '@material-ui/icons/Menu';
import Footer from '../Footer';

const MobileHeader = (props) => {

  const {
    classes,
    showAdmin,
    handleClick,
    showMenu,
    currentUser,
    cartCount,
    signOutUser,
    goToLink
  } = props

  return (
    <>
      <Container maxWidth='lg' style={{ height: '100%' }}>
        <Grid container justify='space-between' alignItems='center' >
          <Typography variant='h2' style={{ color: '#000', fontSize: '16pt' }}>
              tyler bastarache
          </Typography>
          <MenuIcon onClick={handleClick} htmlColor='#000' style={{ cursor: 'pointer' }} />
          </Grid>
        {showMenu && <Grid container direction='column' justify='center' alignItems='center' style={{ height: '100%' }}>
          <Grid className={classes.menuContainer}>
            {showAdmin && <Grid onClick={() => goToLink('/admin')} className={classes.mobileHeaderLinks}>
              admin
              </Grid>}
            <Grid onClick={() => goToLink('/')} className={classes.mobileHeaderLinks}>
              design
              </Grid>
            <Grid onClick={() => goToLink('/music')} className={classes.mobileHeaderLinks}>
              music
              </Grid>
            <Grid onClick={() => goToLink('/about')} className={classes.mobileHeaderLinks}>
              about
              </Grid>
            <Grid onClick={() => goToLink('/contact-us')} className={classes.mobileHeaderLinks}>
              contact
            </Grid>
            <Grid onClick={() => goToLink('/checkout')} className={classes.mobileHeaderLinks}>
              bag ({cartCount})
            </Grid>
            {currentUser
              ? <Grid onClick={signOutUser} className={classes.mobileHeaderLinks}>
                  sign out {currentUser.name}
                </Grid>
              : <Grid onClick={() => goToLink('/login')} className={classes.mobileHeaderLinks}>
                login
                </Grid>}
            </Grid>
          </Grid>}
        </Container>
      {showMenu && <Footer />}
    </>
  )
}

export default withStyles(styles)(MobileHeader)
