import React, { useState, useContext, useEffect } from 'react'
import styles from './styles'
import withStyles from '@material-ui/core/styles/withStyles'
import { AppBar, Container } from '@material-ui/core';
import DesktopHeader from './DesktopHeader';
import { useTheme } from '@material-ui/core/styles';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import MobileHeader from './MobileHeader';
import { useApolloClient } from '@apollo/client';
import { CART } from '../../queries';
import UserContext from '../../containers/App/UserContext'
import { Link, useHistory } from 'react-router-dom'

const TylerHeader = ({ classes, showAdmin }) => {

  const theme = useTheme()
  const matches = useMediaQuery(theme.breakpoints.up('md'));

  const [showMenu, setShowMenu] = useState(false)
  const [anchorEl, setAnchorEl] = useState(null);
  const [cartCount, setCartCount] = useState(0)
  const { setCurrentUser, currentUser } = useContext(UserContext)

  let client = useApolloClient()

  useEffect(() => {
    client.query({
      query: CART,
      fetchPolicy: 'network-only'
    }).then((res) => {
      setCartCount(res.data?.cart?.songs?.length || 0)
  })
  }, [anchorEl])

  const handleClick = () => setShowMenu(!showMenu)

  const handleMenuClick = (e) => {
    setAnchorEl(anchorEl ? null : e.currentTarget)
  }

  const signOutUser = () => {
    localStorage.removeItem('user-token')
    setCurrentUser(null)
  }


  const goToLink = (route) => {
    setShowMenu(false)
    setAnchorEl(null)
    history.push(route)
  }

  let history = useHistory()


  return (
    <AppBar className={classes.tylerHeaderContainer} style={{ height: (showMenu && !matches) ? '102.3vh': ''}}>
      {matches
        ? <DesktopHeader
          showAdmin={showAdmin}
          cartCount={cartCount}
          anchorEl={anchorEl}
          currentUser={currentUser}
          signOutUser={signOutUser}
          handleClick={handleMenuClick}
          goToLink={goToLink}
          />
        : <MobileHeader
          showAdmin={showAdmin}
          handleClick={handleClick}
          showMenu={showMenu}
          currentUser={currentUser}
          cartCount={cartCount}
          signOutUser={signOutUser}
          goToLink={goToLink}
          />}
    </AppBar>
  )
}

export default withStyles(styles)(TylerHeader)
