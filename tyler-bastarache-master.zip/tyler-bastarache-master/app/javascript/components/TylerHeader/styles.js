const styles = theme => ({

  tylerHeaderContainer: {
    borderBottom: 'unset',
    backgroundColor: '#fff',
    padding: '15px 0',
    boxShadow: 'unset',
    // [theme.breakpoints.down('md')]: {
    //   height: '102.3vh'
    // }
  },

  menuContainer: {
    display: 'flex',
    flexDirection: 'column',
    width: '100%',
    height: '75vh',
    overflowY: 'auto'
  },

  headerLinks: {
    margin: '0 0.7rem',
    cursor: 'pointer',
    fontSize: '13pt',
    color: '#000',
    textDecoration: 'none'
  },

  mobileHeaderLinks: {
    width: '100%',
    textAlign: 'center',
    cursor: 'pointer',
    fontSize: '24pt',
    color: '#000',
    textDecoration: 'none',
    padding: '2rem 0'
  },

  tooltip: {
    backgroundColor: 'white',
    padding: '0'
  },

  dropdownMenuItem: {
    borderBottom: '1px solid #000',
    padding: '10px 0 2px 0'
  },

  menuItemText: {
    marginLeft: '8px',
    fontSize: '13pt'
  },

  navDropdownButton: {
    padding: '0',
    width: '100%',
    justifyContent: 'flex-start',
    textTransform: 'unset'
  }

})

export default styles
