import React from 'react'
import styles from './styles'
import withStyles from '@material-ui/core/styles/withStyles'
import { AppBar, Typography, Grid, Container, Popover, Button, Popper, Tooltip } from '@material-ui/core';
import { Link, useHistory } from 'react-router-dom'
import BagIcon from 'images/icons/Bag_Nav.png';
import AccountIcon from 'images/icons/Account_SubNav.png';
import SignInIcon from 'images/icons/Sign_In_Nav.png';
import SignOutIcon from 'images/icons/SignOut_SubNav.png';
import DropdownArrowIcon from '@material-ui/icons/KeyboardArrowUp';

const DesktopHeader = (props) => {

  const {
    classes,
    showAdmin,
    cartCount,
    anchorEl,
    currentUser,
    signOutUser,
    handleClick,
    goToLink,
  } = props

  return (
    <AppBar className={classes.tylerHeaderContainer}>
      <Container maxWidth='lg'>
        <Grid container justify='space-between' alignItems='center' >
          <Grid item lg={8} md={7}>
            <Typography variant='h2' style={{ color: '#000', fontSize: '16pt' }}>
                tyler bastarache
            </Typography>
          </Grid>
          <Grid item lg={showAdmin ? 4 : 3} md={showAdmin ? 5 : 4} container align='center' justify='space-between'>
            {showAdmin && <Link to='/admin' className={classes.headerLinks}>
              admin
            </Link>}
            <Link to='/' className={classes.headerLinks} style={{ marginLeft: 0 }}>
              design
            </Link>
            <Link to='/music' className={classes.headerLinks}>
              music
            </Link>
            <Link to='/about' className={classes.headerLinks}>
              about
            </Link>
            <Link to='/contact-us' className={classes.headerLinks}>
              contact
            </Link>
            <img src={BagIcon} onClick={handleClick} className={classes.headerLinks} style={{ marginRight: 0, width: 20 }}/>
              <Popper
                open={!!anchorEl}
                anchorEl={anchorEl}
                placement='bottom-end'
                style={{ zIndex: '1000000', marginTop: '1rem', border: '1px solid #000', backgroundColor:'#fff', position: 'relative', minWidth: '200px', borderRadius: '7px'
              }}
              >
                <Grid container direction='column' style={{ zIndex: '1000000', padding: '0rem 0.8rem 1rem 0.8rem' }} >
                  <Grid container alignItems='center' className={classes.dropdownMenuItem}>
                    <Button onClick={() => goToLink('/checkout')} className={classes.navDropdownButton}>
                    {/* <BagIcon htmlColor='#000' /> */}
                      <img src={BagIcon} width="18px" height="18px" />
                      <Typography className={classes.menuItemText}>bag ({cartCount}) </Typography>
                    </Button>
                  </Grid>
                  <Grid container alignItems='center' className={classes.dropdownMenuItem}>
                    <Button onClick={() => goToLink('/account')} className={classes.navDropdownButton}>
                      {/* <BagIcon htmlColor='#000' /> */}
                      <img src={AccountIcon} width="18px" height="18px" />
                      <Typography className={classes.menuItemText}>account</Typography>
                    </Button>
                  </Grid>
                  <Grid container alignItems='center' className={classes.dropdownMenuItem}>
                    {currentUser
                      ? <Button onClick={signOutUser} className={classes.navDropdownButton}>
                          <img src={SignOutIcon} width="18px" height="18px" />
                      <Typography className={classes.menuItemText}>sign out {currentUser.name}</Typography>
                        </Button>
                      : <Button onClick={() => goToLink('/login')} className={classes.navDropdownButton}>
                          <img src={SignInIcon} width="18px" height="18px" />
                          <Typography className={classes.menuItemText}>login</Typography>
                        </Button>}
                  </Grid>
                </Grid>
              </Popper>
          </Grid>
        </Grid>
      </Container>
    </AppBar>
  )
}

export default withStyles(styles)(DesktopHeader)
