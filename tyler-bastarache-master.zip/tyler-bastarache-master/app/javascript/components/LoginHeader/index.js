import React from 'react'
import styles from './styles'
import withStyles from "@material-ui/core/styles/withStyles"
import { Grid, Typography } from '@material-ui/core'
const LoginHeader = ({ classes }) => {
  return (
    <Grid className={classes.loginHeaderContainer}>
      <Typography variant='h2' align='center' className={classes.loginTitle}>
        tyler bastarache
      </Typography>
    </Grid>
  )
}

export default withStyles(styles)(LoginHeader)
