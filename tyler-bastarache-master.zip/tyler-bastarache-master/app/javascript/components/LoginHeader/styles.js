const styles = theme => ({

  loginHeaderContainer: {
    borderBottom: '1px solid #000',
    padding: '20px 0'
  },

  loginTitle: {
    fontSize: "16pt"
  }

})

export default styles
