import paypalIcon from '../../images/paypalImage.png'

const styles = theme => ({

  modalContainer: {
    padding: '30px 30px',
    backgroundColor: '#fff',
    outline: 'none',
    width: '100%',
    maxWidth: '600px'
  },

  modalMainContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  },

  modalTitle: {
    fontSize: "26px"
  },

  pdfIconContainer: {
    maxWidth: '95px',
    marginTop: '2rem'
  },

  pdfText: {
    fontSize: '11px',
    marginTop: '0.5rem'
  },

  emailField: {
    borderRadius: '6px',
    border: 'none',
    padding: '8px 15px',
    width: '90%',
    backgroundColor: 'lavender',
    marginTop: '1.8rem',
    marginBottom: '1rem'
  },

  pdfButton: {
    width: '100px',
    height: '40px',
    background: `url(${paypalIcon})`,
    backgroundPosition: 'center',
    backgroundSize: 'cover'
  }

})

export default styles
