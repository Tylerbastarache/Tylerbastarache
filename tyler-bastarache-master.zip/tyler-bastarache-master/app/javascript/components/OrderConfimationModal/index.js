import React, { useState } from "react";
import styles from "./styles";
import withStyles from "@material-ui/core/styles/withStyles";
import pdfIcon from "../../images/pdfIcon.svg";
import {
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  Grid,
  Modal,
  Typography,
} from "@material-ui/core";
import { CheckBox, CheckBoxOutlineBlank } from "@material-ui/icons";

const OrderConfirmationModal = ({
  classes,
  openCheckoutModal,
  setOpenCheckoutModal,
  paymentCheckout,
}) => {
  return (
    <Modal open={openCheckoutModal} className={classes.modalMainContainer}>
      <Grid className={classes.modalContainer}>
        <Grid style={{ display: "flex", justifyContent: "space-between" }}>
          <Typography className={classes.modalTitle}>
            read pdf before purchasing
          </Typography>
          <Typography
            className={classes.modalTitle}
            style={{ cursor: "pointer" }}
            onClick={() => setOpenCheckoutModal(false)}
          >
            X
          </Typography>
        </Grid>
        <Grid
          container
          direction="column"
          alignItems="center"
          className={classes.pdfIconContainer}
        >
          <img src={pdfIcon} width="60px" height="70px" />
          <Typography className={classes.pdfText}>
            Exculsive Contract
          </Typography>
        </Grid>
        <Box my={2}>
          <FormControlLabel
            control={
              <Checkbox
                icon={<CheckBoxOutlineBlank fontSize="small" />}
                checkedIcon={<CheckBox fontSize="small" />}
                name="checkedI"
              />
            }
            label="i agree to the exclusive contract"
          />
        </Box>
        <Box mb={1}>
          <Typography className={classes.modalTitle}>services</Typography>
        </Box>
        <Typography>
          all instrumentals can be customized to you’re liking. significant
          alterations will result in an additional cost of $500 USD. for any
          custom inquiries contact me at{" "}
          <strong>tyler.bastarache@hotmail.com</strong>
        </Typography>
        <Box my={2}>
          <Typography>
            <strong>free:</strong> rearranging/removing instruments.
          </Typography>
          <Typography>
            <strong>aditional $50:</strong> adding melodies, drum fills, effects
            or sounds
          </Typography>
        </Box>
        <Typography>
          custom album/single cover can be discussed by email.
        </Typography>
        <input
          placeholder="email"
          type="email"
          className={classes.emailField}
        />
        <Button
          onClick={() => paymentCheckout()}
          className={classes.pdfButton}
        />
      </Grid>
    </Modal>
  );
};

export default withStyles(styles)(OrderConfirmationModal);
