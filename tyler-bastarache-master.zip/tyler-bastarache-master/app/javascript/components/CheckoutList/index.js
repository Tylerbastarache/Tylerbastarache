import React, { useState } from "react";
import styles from "./styles";
import withStyles from "@material-ui/core/styles/withStyles";
import AudioCard from "../AudioCard";
import testAudio from "videos/test_audio.mp3";
import { Box, Grid } from "@material-ui/core";

const CheckoutList = (props) => {
  const { classes, cartData } = props;

  const [progress, setProgress] = useState(0);
  const [currentPlayer, setCurrentPlayer] = useState(null);

  const resetAllPlayers = () => {
    currentPlayer && currentPlayer.element.pause();
    setCurrentPlayer(null);
    setProgress(0);
  };

  const playAudio = (id) => {
    resetAllPlayers();
    let audioElement = document.getElementById(`audio_player_${id}`);
    setCurrentPlayer({ id: id, element: audioElement });
    audioElement.play();
  };

  const stopAudio = (id) => {
    let audioElement = document.getElementById(`audio_player_${id}`);
    setCurrentPlayer(null);
    audioElement.pause();
    setProgress(0);
  };

  return (
    <Grid container justify='space-between'>
      {cartData?.songs?.map((audio) => (
        <Box style={{ marginRight: '52px'}}>
          <AudioCard
            progress={progress}
            duration={currentPlayer && currentPlayer.element.duration}
            isActive={currentPlayer && currentPlayer.id === audio.id}
            audioId={audio.id}
            title={audio.title}
            price={audio.price}
            thumb={audio.backgroundImageUrl}
            src={audio.audioFileUrl}
            setProgress={setProgress}
            playAudio={playAudio}
            stopAudio={stopAudio}
            showChip={false}
          />
        </Box>
      ))}
    </Grid>
  );
};

export default withStyles(styles)(CheckoutList);
