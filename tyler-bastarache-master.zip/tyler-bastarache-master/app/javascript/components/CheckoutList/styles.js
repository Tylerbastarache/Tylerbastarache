const styles = theme => ({

  loginHeaderContainer: {
    borderBottom: '1px solid #000',
    padding: '15px 0'
  },

  loginTitle: {
    fontSize: "26px"
  }

})

export default styles
