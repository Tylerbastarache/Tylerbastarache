const styles = theme => ({

  audioThumb: {
    width: '296px',
    height: '300px',
    padding: '1rem',
    position: 'relative',
    backgroundColor: 'lavender',
    backgroundSize: 'cover',
    backgroundPosition: 'center'
  },

  chipLabel: {
    padding: '0 4px'
  },

  chipText: {
    color: '#fff',
    fontSize: '13pt',
  },

  playerLoader: {
    width: '86px',
    position: 'absolute',
    height: '98px',
    bottom: '13px',
    right: '13px',
  },

  playerControls: {
    fontSize: '4rem',
    zIndex: '100',
  },

  chipStyle: {
    backgroundColor: 'black',
    height: '23px',
    border: '1px solid black',
    '&:hover': {
      backgroundColor: '#fff',
      // borderColor: '#fff',
      '& p': {
        color: '#000'
      },
      '& svg': {
        color: '#000'
      },
      '& img': {
        filter: 'invert(0)'
      }
    },
  },

  chipIcon: {
    filter: 'invert(1)',
    marginRight: '5px',
    marginLeft: '2px',
    width: '20px',
    height: '20px',
  }
})

export default styles
