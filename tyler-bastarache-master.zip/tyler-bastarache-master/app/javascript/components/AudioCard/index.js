import React from "react";
import ReactAudioPlayer from "react-audio-player";
import styles from "./styles";
import withStyles from "@material-ui/core/styles/withStyles";
import {
  CircularProgress,
  Grid,
  Box,
  Typography,
  Chip,
} from "@material-ui/core";
// import BagIcon from 'images/icons/Bag_Nav.png';
import BagIcon from "images/icons/Bag_Nav.png";
import PlayMusic from "@material-ui/icons/PlayCircleOutline";
import PauseMusic from "@material-ui/icons/PauseCircleOutline";

const AudioCard = (props) => {
  const {
    classes,
    progress,
    duration,
    isActive,
    audioId,
    playAudio,
    stopAudio,
    showChip,
    addToCart,
    title,
    price,
    thumb,
    src,
    setProgress,
    purchased,
  } = props;

  const renderPlayerControls = () => {
    if (isActive) {
      return (
        <>
          <CircularProgress
            variant="determinate"
            value={(progress / duration) * 100}
            size={70}
            className={classes.playerLoader}
          />
          <PauseMusic
            id={`pause_${audioId}`}
            className={classes.playerControls}
            // className="pause-button"
            onClick={() => stopAudio(audioId)}
          />
        </>
      );
    } else
      return (
        <PlayMusic
          id={`play_${audioId}`}
          // className="play-button"
          className={classes.playerControls}
          onClick={() => playAudio(audioId)}
        />
      );
  };

  const renderChip = () => {
    return (
      <Chip
        onClick={() => addToCart(audioId)}
        className={classes.chipStyle}
        // style={ }
        label={
          <Grid
            container
            alignItems="center"
            justify="space-between"
            style={{ width: 70 }}
          >
            <img src={BagIcon} className={classes.chipIcon} />
            <Typography className={classes.chipText}>${price}</Typography>
          </Grid>
        }
        classes={{
          label: classes.chipLabel,
        }}
      />
    );
  };

  return (
    <Grid style={{ marginBottom: "52px" }}>
      <Grid
        container
        justify="flex-end"
        alignItems="flex-end"
        className={classes.audioThumb}
        style={{ backgroundImage: `url('${thumb}')` }}
      >
        {
          <ReactAudioPlayer
            id={`audio_player_${audioId}`}
            src={src}
            listenInterval={1000}
            volume={0.1}
            onListen={(e) => setProgress(e)}
          />
        }
        {renderPlayerControls()}
      </Grid>
      <Box style={{ marginTop: "18px" }}>
        <Grid container justify="space-between">
          <Typography
            variant="h3"
            style={{ fontSize: "20pt", lineHeight: "0.7" }}
          >
            {title}
          </Typography>
          {showChip ? (
            renderChip()
          ) : (
            <Typography style={{ color: "#000", fontSize: "15pt" }}>
              {!purchased && `$${price}`}
            </Typography>
          )}
        </Grid>
      </Box>
    </Grid>
  );
};

export default withStyles(styles)(AudioCard);
