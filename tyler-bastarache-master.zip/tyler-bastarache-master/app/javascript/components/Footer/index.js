import React from 'react'
import styles from './styles'
import withStyles from "@material-ui/core/styles/withStyles"
import { Grid, Typography } from '@material-ui/core'
const Footer = ({ classes, noFooterSpacing }) => {
  return (
    <Grid className={classes.footerContainer} style={{ marginTop: noFooterSpacing ? '0' : '50px'}}>
      <Typography variant='h3' align='center' className={classes.loginTitle}>
        @ tyler bastarache 2021
      </Typography>
    </Grid>
  )
}

export default withStyles(styles)(Footer)
