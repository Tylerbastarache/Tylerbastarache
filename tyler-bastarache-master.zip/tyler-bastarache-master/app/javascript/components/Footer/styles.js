const styles = theme => ({

  footerContainer: {
    padding: '15px 0',
    marginTop: '50px',
    backgroundColor: '#ececec'
  },

  loginTitle: {
    fontSize: "17px",
    color: '#000'
  }

})

export default styles
