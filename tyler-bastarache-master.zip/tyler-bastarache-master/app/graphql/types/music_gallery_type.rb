module Types
  class MusicGalleryType < BaseObject
    field :my_songs, [SongType], null: true
    field :songs, [SongType], null: true
  end
end
