module Types
  class MutationType < Types::BaseObject
    field :sign_up_user, mutation: Mutations::SignUpUser
    field :sign_in_user, mutation: Mutations::SignInUser
    field :create_song, mutation: Mutations::CreateSong
    field :remove_song, mutation: Mutations::RemoveSong
    field :add_to_cart, mutation: Mutations::AddToCart
    field :remove_from_cart, mutation: Mutations::RemoveFromCart
    field :checkout, mutation: Mutations::Checkout
  end
end
