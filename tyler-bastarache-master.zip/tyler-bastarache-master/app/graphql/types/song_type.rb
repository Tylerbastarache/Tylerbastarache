module Types
  class SongType < BaseObject
    field :id, ID, null: true
    field :title, String, null: true
    field :description, String, null: true
    field :background_image_url, String, null: true
    field :audio_file_url, String, null: true
    field :price, Float, null: true
  end
end
