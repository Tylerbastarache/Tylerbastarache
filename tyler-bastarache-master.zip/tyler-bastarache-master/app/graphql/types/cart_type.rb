module Types
  class CartType < BaseObject
    field :id, ID, null: true
    field :songs, [SongType], null: true
  end
end
