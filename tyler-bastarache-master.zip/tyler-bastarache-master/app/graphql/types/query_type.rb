module Types
  class QueryType < Types::BaseObject
    # Add `node(id: ID!) and `nodes(ids: [ID!]!)`
    # include GraphQL::Types::Relay::HasNodeField
    # include GraphQL::Types::Relay::HasNodesField

    # Add root-level fields here.
    # They will be entry points for queries on your schema.

    # TODO: remove me
    field :get_current_user, UserType, null: true
    def get_current_user
      current_user
    end

    field :cart, CartType, null: true
    def cart
      current_user&.cart
    end

    field :user_songs, [SongType], null: true
    def user_songs
      current_user.songs
    end

    field :songs, MusicGalleryType, null: true
    def songs
      {my_songs: current_user&.songs || [], songs:  Song.where.not(id: current_user&.song_ids)}
    end

  end
end
