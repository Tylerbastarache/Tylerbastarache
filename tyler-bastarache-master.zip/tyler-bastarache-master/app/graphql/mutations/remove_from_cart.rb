module Mutations
  class RemoveFromCart < BaseMutation
    argument :song_id, Integer, required: true

    type Types::CartType

    # def allow?(**params)
    #   true
    # end

    def resolve(song_id:)
      cart = Cart.find_by(user_id: current_user.id)
      ids = cart.song_ids + [song_id]
      cart.song_ids = ids.uniq
      cart
    end
  end
end
