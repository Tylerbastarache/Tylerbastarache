module Mutations
  class Checkout < BaseMutation
    argument :song_ids, [Integer], required: true
    field :url, String, null: true
    field :error, String, null: true

    # def allow?(song_ids:)
    #   true
    # end

    def resolve(song_ids:)
      ids = current_user.song_ids + song_ids
      # current_user.song_ids  = ids
      songs = Song.where(id: song_ids)
      items = songs.map do|song|
        {
          name: song.title,
          sku: song.id.to_s,
          price: song.price.to_s,
          currency: "USD",
          quantity: 1
        }
      end
      total = songs.pluck(:price).sum.round(2).to_s
      payment_url(items,total)
      # current_user.cart.destroy
    end

    def payment_url(items, total)
      payment = Payment.new({
        intent:  "sale",
        # Set payment type
        payer:  {
          payment_method:  "paypal"
        },
        # Set redirect URLs
        redirect_urls: {
          return_url: "https://tyler-music.herokuapp.com/execute?&user_id=#{current_user.id}",
          cancel_url: "https://tyler-music.herokuapp.com"
        },
        # Set transaction object
        transactions:  [{
          # Items
          item_list: {
            items: items
          },
          # Amount - must match item list breakdown price
          amount:  {
            total:  total,
            currency:  "USD"
          },
          description:  "payment description."
        }]
      })

      # Create payment
      if payment.create
        # Capture redirect url
        return {url: payment.links.find{|v| v.rel == "approval_url" }.href}
        # Redirect the customer to redirect_url
      else
        return {error: payment.error.inspect}
      end
    end
  end
end