module Mutations
  class CreatePayment < BaseMutation
    argument :title, String, required: true
    argument :description, String, required: false
    argument :background_image, ApolloUploadServer::Upload, required: false
    argument :audio_file, Types::FileType, required: true
    argument :price, String, required: true

    type Types::SongType

    # def allow?(**params)
    #   true
    # end

    def resolve(**params)
      # Create payment object
      payment = Payment.new({
        :intent =>  "sale",
        # Set payment type
        :payer =>  {
          :payment_method =>  "paypal"
        },
        # Set redirect URLs
        :redirect_urls => {
          :return_url => "https://tyler-music.herokuapp.com//execute",
          :cancel_url => "https://tyler-music.herokuapp.com/"
        },
        # Set transaction object
        :transactions =>  [{
          # Items
          :item_list => {
            :items => [{
              :name => "item",
              :sku => "item",
              :price => "10",
              :currency => "USD",
              :quantity => 1
            }]
          },
          # Amount - must match item list breakdown price
          :amount =>  {
            :total =>  "10",
            :currency =>  "USD"
          },
          :description =>  "payment description."
        }]
      })

      # Create payment
      if payment.create
        # Capture redirect url
        redirect_url = payment.links.find{|v| v.rel == "approval_url" }.href

        # Redirect the customer to redirect_url
      else
        logger.error payment.error.inspect
      end

      # # Get payment ID from query string following redirect
      # payment = Payment.find(ENV["PAYMENT_ID"])
      # # Execute payment with the payer ID from query string following redirect
      # if after_payment.execute( :payer_id => 'EC-75H57276K97329259&PayerID=2DCGJQJC2DMFJ' )  #return true or false
      #   logger.info "Payment[#{payment.id}] executed successfully"
      # else
      #   logger.error payment.error.inspect
      # end
    end
  end
end
