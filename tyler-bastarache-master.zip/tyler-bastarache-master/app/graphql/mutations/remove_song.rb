module Mutations
  class RemoveSong < BaseMutation
    argument :id, Integer, required: true

    type Boolean

    # def allow?(**params)
    #   true
    # end

    def resolve(id:)
      Song.find(id).destroy
    end
  end
end
