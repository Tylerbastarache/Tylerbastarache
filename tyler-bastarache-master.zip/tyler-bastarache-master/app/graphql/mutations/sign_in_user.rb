module Mutations
  class SignInUser < BaseMutation
    null true

    argument :credentials, Types::Input::AuthProviderCredentialsInput, required: false

    field :token, String, null: true
    field :user, Types::UserType, null: true
    field :error, String, null: true

    def allow?(**params)
      true
    end

    def resolve(credentials: nil)
      # basic validation
      return {error: "unauthorized"} unless credentials

      user = User.find_by email: credentials[:email]

      # ensures we have the correct user
      return {error: "unauthorized"}  unless user
      return {error: "unauthorized"}  unless user.valid_password?(credentials[:password])
      # use Ruby on Rails - ActiveSupport::MessageEncryptor, to build a token
      crypt = ActiveSupport::MessageEncryptor.new(ENV['MOBILE_SECRET_KEY'].byteslice(0..31))
      token = crypt.encrypt_and_sign("user-id:#{ user.id }")
      { user: user, token: token }
    end
  end
end
