module Mutations
  class CreateSong < BaseMutation
    argument :title, String, required: true
    argument :description, String, required: false
    argument :background_image, ApolloUploadServer::Upload, required: false
    argument :audio_file, Types::FileType, required: true
    argument :price, String, required: true

    type Types::SongType

    # def allow?(**params)
    #   true
    # end

    def resolve(**params)
      song = Song.new(params.except(:background_image, :audio_file))
      if params[:background_image].present?
        hero_image = ActiveStorage::Blob.create_after_upload!(
          io: params[:background_image],
          filename: params[:background_image].original_filename,
          content_type: params[:background_image].content_type
        )
        song.background_image.attach(hero_image)
      end

      if params[:audio_file].present?
        song.audio_file.attach(params[:audio_file])
      end

      song.save!
      song
    end
  end
end
