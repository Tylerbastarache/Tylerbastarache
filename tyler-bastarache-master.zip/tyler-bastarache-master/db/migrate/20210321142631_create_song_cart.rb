class CreateSongCart < ActiveRecord::Migration[6.1]
  def change
    create_table :song_carts do |t|
      t.integer :cart_id
      t.integer :song_id
      t.timestamps
    end
  end
end
