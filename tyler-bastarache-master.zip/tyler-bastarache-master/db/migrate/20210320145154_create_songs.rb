class CreateSongs < ActiveRecord::Migration[6.1]
  def change
    create_table :songs do |t|
      t.string  :title
      t.float :price, default: 0.0
      t.text :description
      t.string :audio_file
      t.string :background_image
      t.timestamps
    end
  end
end
