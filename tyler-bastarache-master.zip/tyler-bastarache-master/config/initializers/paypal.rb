require 'paypal-sdk-rest'
include PayPal::SDK::REST
include PayPal::SDK::Core::Logging

PayPal::SDK.configure(
  :mode => 'live', #sandbox or live
  :client_id => "ATAqZnIjFut8INWr8IhWxvYbpCAZ_EAO4bwvGSZJuzi4CuwgBiP3yoorfR2PLAYguwc7Tpdr2entrky0", #my sandbox 'AfA2wI7I18784Jl2Avwe7nZbHvGFU1jFkSV7N5Y5PppaEXMiK3534glFcb-jMRhY3Yx3J2cGQxG7Y0vV',
  :client_secret => "EFJry7BAC21OnJCbBb4kszohC3r-5R4aR-hWfpGquGvtC6zo-iY15A2eM59td-v8MO0gQzH-3KQFBK3s", # my sandbox'EJWGCPu-qTC02XYae5cH4fjl-hYfHtJ2_JiPwDF8Ha7za2wrehM7aVMmsOObOS6gIXQkqde97SoD7dUV',
  :ssl_options => { ca_file: nil } )