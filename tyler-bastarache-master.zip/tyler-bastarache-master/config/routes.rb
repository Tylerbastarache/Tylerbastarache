Rails.application.routes.draw do
  devise_for :users
  if Rails.env.development?
    mount GraphiQL::Rails::Engine, at: "/graphiql", graphql_path: "/graphql"
  end
  post "/graphql", to: "graphql#execute"
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
  root to: 'home#index'
  get 'execute', to: 'home#execute'
  get 'error', to: 'home#error'
  get '/', to: 'home#index'
  get '/music', to: 'home#index'
  get '/admin', to: 'home#index'
  get '/add-new-music', to: 'home#index'
  get '/contact-us', to: 'home#index'
  get '/about', to: 'home#index'
  get '/execute', to: 'home#index'
  get '/login', to: 'home#index'
  get '/sign-up', to: 'home#index'
  get '/checkout', to: 'home#index'
  get 'portfolio/:id', to: 'home#index'
  get '/account', to: 'home#index'
  # get '/account', to: 'home#index'
  # match '(*any)', to: 'home#index', via: %i[get post]
end
